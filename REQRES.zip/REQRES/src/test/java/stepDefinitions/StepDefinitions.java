package stepDefinitions;

import io.cucumber.java.ParameterType;
import io.cucumber.java.en.*;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

public class StepDefinitions {
// base Uri = https://reqres.in/api/users

	private String baseUri,requestBody,token;
	private Response response;
	private int userID;

	@ParameterType("\\d+")
	public Integer integer(String value) {
		return Integer.parseInt(value);
	}

	@Given("set base uri {string}")
	public void set_base_uri(String uri) {
		baseUri = uri;
	}

	@When("I Sended the GET request to {string}")
	public void i_sended_the_get_request_to(String endPoint) {
		response = given().baseUri(baseUri).header("Accept", "*/*").when().get("/" + endPoint);
	}

	@Then("I validate the statuscode {integer}")
	public void i_validate_the_statuscode(Integer code) {
		System.out.println(response.getBody().asString());
		assertEquals(code.intValue(), response.getStatusCode());
	}

	@Given("I will send the user ID {integer}")
	public void i_will_send_the_user_id(Integer id) {
		userID = id.intValue();
	}

	@When("I will send GET request by {string} and ID")
	public void i_will_send_get_request_by_and_id(String resource) {
		response = given().baseUri(baseUri).basePath("/" + resource).header("Accept", "*/*").when().get("/" + userID);
	}

	@Then("I validate the statuscode {integer} and {integer} in the response")
	public void i_validate_the_statuscode_and_in_the_response(Integer code, Integer id) {
		// Validate the status code
		if (response.getStatusCode() != 200)
			System.out.println("Status Code" + response.getStatusCode());
		assertEquals(code.intValue(), response.getStatusCode());
		System.out.println(response.getBody().asString());

		// validate the id are equal are not
		JsonPath js = new JsonPath(response.asString());
		assertEquals(id, Integer.parseInt(js.getString("data.id")));
	}

//------------------------------------------------------------------------------------------------------------------------------------
//CURD Operations @Create @Update @Delete

	// --> Scenario: Creating a new User

	@Given("SetUp the baseUri {string}")
	public void set_up_the_base_uri(String endpoint) {
		baseUri = endpoint;
	}

	@When("I will send the POST Request with body:")
	public void i_will_send_the_post_request_with_body(String body) {
		response = given().baseUri(baseUri).header("Accept", "*/*").body(body).when().post();
	}

	@Then("I should receive status code {int}")
	public void i_should_receive_status_code(Integer code) {
		assertEquals(code, response.getStatusCode());
		System.out.println(response.getBody().asString());
	}

	// --> Scenario: Update user deatils
	// Using PUT and PATCH

	@Given("SettinUp the baseUri {string} and id {integer} and body:")
	public void settin_up_the_base_uri_and_id_and_body(String endpoint, Integer id, String body) {
		baseUri = endpoint;
		userID = id;
		requestBody = body;
	}

	@When("I will send the PUT Request")
	public void i_will_send_the_put_request() {
		response = given().baseUri(baseUri).header("Accept", "*/*").body(requestBody).when().patch("/" + userID).then()
				.log().all().extract().response();
	}

	@Then("I will validate the status {integer} and response body")
	public void i_will_validate_the_status_code_and_response_body(Integer code) {

		// validating the status code
		assertEquals(code, response.getStatusCode());

		System.out.println(response.getBody().asString());

		// validate the response body
		JsonPath js = new JsonPath(response.asString());
		assertTrue(js.get("updatedAt") != null);

	}

	// Scenario: Register a new user

	@Given("Setting up the BaseUri {string} and the body:")
	public void setting_up_the_base_uri_and_the_body(String endpoint, String body) {
		baseUri = endpoint;
		requestBody = body;
	}

	@When("I send the POST Request")
	public void i_send_the_post_request() {
//		System.out.println(baseUri);
		response = given().baseUri(baseUri).header("Content-Type","application/json").body(requestBody).when().post();
	}

	@Then("I should get valid response")
	public void i_should_get_valid_response() {
		if (response.getStatusCode() == 200) {
			token = response.getBody().jsonPath().get("token");
			System.out.println("Registered Successful,token: "+token);
		} else {
			System.out.println("Error: "+response.getBody().jsonPath().get("error"));
			assertTrue(response.getStatusCode() == 200);
		}
			

	}

	// Scenario: Login using email and passowrd

	@Given("setting up baseUri {string} and body")
	public void setting_up_base_uri_and_body(String endpoint, String body) {
		baseUri = endpoint;
		requestBody = body;
	}

	@When("I send the Post Request")
	public void i_send_the_post_Request() {
		response = given().baseUri(baseUri).header("Content-Type","application/json").body(requestBody).when().post();
	}

	@Then("i should receive a valid response")
	public void i_should_receive_a_valid_response() {
		if (response.getStatusCode() != 200) {
			System.out.println("Error: " + response.getBody().jsonPath().get("error"));
		} else {
			assertTrue(response.getStatusCode() == 200);
			System.out.println("Login Successful,token: " + response.getBody().jsonPath().get("token"));
		}
	}

}
