
import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
// --> Access User Details
//Users(GET)
//@CucumberOptions(features = {"src/test/java/feature/GetUserDetails.feature","src/test/java/feature/GetSingleUser.feature"})

//Resource(GET)
//@CucumberOptions(features = {"src/test/java/feature/GetUserResource.feature","src/test/java/feature/GetSingleResource.feature"})

// --> CRUD
//Create User(POST)
//@CucumberOptions(features = "src/test/java/feature/CreateUser.feature")

//Update User(PUT)
//@CucumberOptions(features = "src/test/java/feature/UpdateUserDetails.feature")

//Update User(PATCH)
//@CucumberOptions(features = "src/test/java/feature/UpdateUserDetailsPATCH.feature")

//Register User(POST)
@CucumberOptions(features = "src/test/java/feature/Registration.feature")

//Login user (POST)
//@CucumberOptions(features = "src/test/java/feature/Login.feature")
public class TestRunner {

}
