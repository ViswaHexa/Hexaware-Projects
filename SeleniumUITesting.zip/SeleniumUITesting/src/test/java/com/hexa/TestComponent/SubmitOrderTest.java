package com.hexa.TestComponent;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.hexa.pageObjectModel.CartPage;
import com.hexa.pageObjectModel.CheckOutPage;
import com.hexa.pageObjectModel.ConformationPage;
import com.hexa.pageObjectModel.productCatalog;

public class SubmitOrderTest extends BaseTest {

	@Test(dataProvider = "getData")
	public void submitOrder(HashMap<String,String> input) {
		
		productCatalog productcatalog = landingpage.loginPage(input.get("userName"),input.get("passWord"));
		productcatalog.getProductList();
		productcatalog.addProductToCart(input.get("product"));
		CartPage cartpage = productcatalog.goToCartPage();
		boolean match = cartpage.verifyProductDisplay(input.get("product"));
		Assert.assertTrue(match);
		CheckOutPage checkoutpage = cartpage.goToCheckout();
		checkoutpage.fillDetails(input.get("fName"),input.get("lName"),input.get("pCode"));
		ConformationPage conformationpage = checkoutpage.submitOrder();
		String conformMsg = conformationpage.getConformationMsg();
		Assert.assertTrue(conformMsg.equalsIgnoreCase("Thank you for your order!"));
		closeBrowser();

	}
	@DataProvider
	public Object[][] getData() throws IOException
	{
//		HashMap<String,String> map = new HashMap<String,String>();
//		map.put("email", "viswa4444@gmail.com");
//		map.put("passWord", "Viswa#4444");
//		map.put("product", "IPHONE 13 PRO");
//		map.put("country", "india");
//		
//		HashMap<String,String> map1 = new HashMap<String,String>();
//		map.put("email", "viswa96033@gmail.com");
//		map.put("passWord", "Viswa#96033");
//		map.put("product", "ADIDAS ORIGINAL");
//		map.put("country", "United States");
		
		List<HashMap<String,String>> data= getJSONDataToHashMap("C:\\Users\\2000107211\\eclipse-workspace\\SeleniumUITesting\\src\\test\\java\\com\\hexa\\Data\\TestData.json");
		
		return new Object[][] {{data.get(0)},{data.get(1)}};
	}

}
