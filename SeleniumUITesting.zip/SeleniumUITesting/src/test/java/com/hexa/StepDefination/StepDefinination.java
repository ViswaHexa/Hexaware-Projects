package com.hexa.StepDefination;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.hexa.TestComponent.BaseTest;
import com.hexa.pageObjectModel.CartPage;
import com.hexa.pageObjectModel.CheckOutPage;
import com.hexa.pageObjectModel.ConformationPage;
import com.hexa.pageObjectModel.landingPage;
import com.hexa.pageObjectModel.productCatalog;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinination extends BaseTest{
	public landingPage landingpage;
	public productCatalog productcatalog;
	public ConformationPage conformationpage;
	@Given("I landed on Ecommerce Page")
	public void I_landed_on_Ecommerce_Page()
	{
		landingpage = launchApplication();
	}
	
	@Given("^Logged in with email (.+) and password (.+)$")
	public void logged_in_with_username_and_password(String email,String passWord)
	{
		productcatalog = landingpage.loginPage(email,passWord);
	}
	
	@When("^I add product (.+) to cart$")
	public void I_add_product_to_cart(String product)
	{
		List<WebElement> options = productcatalog.getProductList();
		productcatalog.addProductToCart(product);
	}
	
	@When("^Checkout (.+) and fill the details and submit the order$")
	public void Checkout_product_and_fill_the_details_and_submit_the_order(String product)
	{
		CartPage cartpage = productcatalog.goToCartPage();
		boolean match = cartpage.verifyProductDisplay(product);
		Assert.assertTrue(match);
		CheckOutPage checkoutpage = cartpage.goToCheckout();
		checkoutpage.fillDetails("Viswa","Sai","515133A");
		conformationpage = checkoutpage.submitOrder();
	}
	
	@Then("{string} message is displayed on ConformationPage")
	public void message_is_displayed_on_ConformationPage(String string)
	{
		String conformMsg = conformationpage.getConformationMsg();
		Assert.assertTrue(conformMsg.equalsIgnoreCase(string));
		closeBrowser();
	}
}
