package com.hexa.pageObjectModel;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.hexa.AbstractCompontent.AbstractComponent;

public class landingPage extends AbstractComponent {
	WebDriver dri;

	public landingPage(WebDriver dri) {
		super(dri);
		this.dri = dri;
		PageFactory.initElements(dri, this);
	}
	
	@FindBy(id="user-name")
	WebElement userName;
	
	@FindBy(id="password")
	WebElement passWord;
	
	@FindBy(id="login-button")
	WebElement login;
	
	public productCatalog loginPage(String Email,String Password)
	{
		userName.sendKeys(Email);
		passWord.sendKeys(Password);
		login.click();
		productCatalog productcatalog = new productCatalog(dri);
		return productcatalog;
	}
	
	public void goTo()
	{
		dri.get("https://www.saucedemo.com/");
	}
	
	
}
