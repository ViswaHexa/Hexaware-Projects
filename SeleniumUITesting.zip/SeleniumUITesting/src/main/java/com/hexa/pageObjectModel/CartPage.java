package com.hexa.pageObjectModel;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hexa.AbstractCompontent.AbstractComponent;

public class CartPage extends AbstractComponent {
	WebDriver dri;
	
	@FindBy(css="#checkout")
	WebElement checkoutEle;
	
	@FindBy(css=".inventory_item_name")
	private List<WebElement> cartProducts;

	public CartPage(WebDriver dri) {
		super(dri);
		this.dri = dri;
	}
	
	public boolean verifyProductDisplay(String productName)
	{
		Boolean match = cartProducts.stream().anyMatch(prod -> prod.getText().equalsIgnoreCase(productName)); 
		return match;
	}
	
	public CheckOutPage goToCheckout()
	{
		checkoutEle.click();
		return new CheckOutPage(dri);
	}
	
	
}
