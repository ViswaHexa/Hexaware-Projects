package com.hexa.pageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.hexa.AbstractCompontent.AbstractComponent;

public class CheckOutPage extends AbstractComponent {

	WebDriver dri;

	public CheckOutPage(WebDriver dri) {
		super(dri);
		this.dri = dri;
		PageFactory.initElements(dri, this);
	}
	
	@FindBy(css="#first-name")
	WebElement firstName;
	
	@FindBy(css="#last-name")
	WebElement lastName;
	
	@FindBy(css="#postal-code")
	WebElement postalCode;
	
	@FindBy(css="#continue")
	WebElement submit;
	@FindBy(css="#finish")
	WebElement finsh;
	
	
	////a[text()="Place Order "]
	
	By results = By.cssSelector(".ta-results");
	
	public void fillDetails(String fName,String lName,String pCode)
	{
		firstName.sendKeys(fName);
		lastName.sendKeys(lName);
		postalCode.sendKeys(pCode);
		submit.click();
		
	}
	public ConformationPage submitOrder() 
	{
		
		finsh.click();
		return new ConformationPage(dri);
	}

}
