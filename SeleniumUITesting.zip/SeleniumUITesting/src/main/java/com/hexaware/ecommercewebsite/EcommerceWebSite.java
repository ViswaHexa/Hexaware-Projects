//package com.hexaware.ecommercewebsite;
//
//import java.util.List;
//
//import org.openqa.selenium.WebElement;
//import org.testng.Assert;
//
//import com.hexa.pageObjectModel.CartPage;
//import com.hexa.pageObjectModel.CheckOutPage;
//import com.hexa.pageObjectModel.ConformationPage;
//import com.hexa.pageObjectModel.landingPage;
//import com.hexa.pageObjectModel.productCatalog;
//
//
//
//
//public class EcommerceWebSite {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		String productName = "ADIDAS ORIGINAL";
//		String country = "india";
//		
//		landingPage landingpage = launchApplication();
//		
//		productCatalog productcatalog = landingpage.loginPage("viswa4444@gmail.com", "Viswa#4444");
//
//		List<WebElement> options = productcatalog.getProductList();
//		productcatalog.addProductToCart(productName);
//		CartPage cartpage = productcatalog.goToCartPage();
//
//		
//		boolean match = cartpage.verifyProductDisplay(productName);
//		
//		Assert.assertTrue(match);
//		CheckOutPage checkoutpage = cartpage.goToCheckout();
//		checkoutpage.SelectCountry(country);
//		ConformationPage conformationpage = checkoutpage.submitOrder();
//
//		String conformMsg = conformationpage.getConformationMsg();
//		Assert.assertTrue(conformMsg.equalsIgnoreCase("THANKYOU FOR THE ORDER."));
//		driver.quit();
//		
//		
//
//	}
//
//}
