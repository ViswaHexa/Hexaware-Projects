package com.hexaware.apitesting;

import static io.restassured.RestAssured.get;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;

public class DefaultValidation {
	
	@BeforeClass
	public void defaultValidations()
	{
		RequestSpecBuilder rb = new RequestSpecBuilder();
		rb.setBaseUri("https://api.postman.com");
		rb.addHeader("x-api-key","PMAK-655dc1680358bc23f0d0b314-4210664036d666414aa83a7f04cdae1377");
		//rb.log(LogDetail.ALL);
		
		RestAssured.requestSpecification = rb.build();
		
//		responseSpecification = RestAssured.expect()
//				.statusCode(200)
//				.contentType(ContentType.JSON);
		
	ResponseSpecBuilder rsb = new ResponseSpecBuilder().expectStatusCode(200).expectContentType(ContentType.JSON);
	RestAssured.responseSpecification = rsb.build();
			
		
		
	}
	@Test
	public void validate_body()
	{
		String name =get("/workspaces")
			.then().log().ifError()
				.assertThat().extract().response().path("workspaces[1].name");
		
		System.out.println("1st WorkSpace name: "+name);
		Assert.assertEquals(name, "myapiworkspace");
	}
	
	@Test
	public void validateStatusCode()
	{
		get("/workspaces")
		.then().assertThat().statusCode(200);
			
	}
}
