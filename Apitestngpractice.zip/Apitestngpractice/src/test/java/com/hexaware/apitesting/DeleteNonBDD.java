package com.hexaware.apitesting;

import static io.restassured.RestAssured.with;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;

public class DeleteNonBDD {
	
	@BeforeClass
	public void requestSpec()
	{
		RequestSpecBuilder rqbuilder = new RequestSpecBuilder()
				.setBaseUri("https://api.postman.com")
				.addHeader("x-api-key","PMAK-655dc1680358bc23f0d0b314-4210664036d666414aa83a7f04cdae1377")
				.setContentType(ContentType.JSON)
				.log(LogDetail.ALL);
		RestAssured.requestSpecification = rqbuilder.build();
		
		ResponseSpecBuilder rsb = new ResponseSpecBuilder()
				.expectStatusCode(200)
				.expectContentType(ContentType.JSON)
				.log(LogDetail.ALL);
		RestAssured.responseSpecification = rsb.build();
	}
	
	@Test
	public void postAutomateWithBDD()
	{	
		String workspaceId = "9bc37bbd-7440-4d0c-87d8-be38faae6734";
		
		 with().delete("/workspaces/"+ workspaceId);
//		assertThat(res.<String>path("workspace.name"),equalTo("MyAPITestingsss"));
//		assertThat(res.<String>path("workspace.id"), matchesPattern("^[a-z0-9-]{36}$"));

		
	}
}
