package com.hexaware.apitesting;

import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class RequestSpecifications {
	RequestSpecification rs;
	@BeforeClass
	public void beforeClass()
	{
		rs = given().baseUri("https://api.postman.com")
				.header("x-api-key","PMAK-655dc1680358bc23f0d0b314-4210664036d666414aa83a7f04cdae1377")
				.log().all();
	}
	
	@Test
	public void requestSpecification()
	{
		String name = given(rs)
				
			.when()
				.get("/workspaces")
			.then().log().ifError()
				.assertThat().statusCode(200).extract().response().path("workspaces[1].name");
		
		System.out.println("1st WorkSpace name: "+name);
		
		
	}
	
	@Test
	public void validate_body()
	{
		String name = given().spec(rs)
				
			.when()
				.get("/workspaces")
			.then().log().ifError()
				.assertThat().statusCode(200).extract().response().path("workspaces[1].name");
		
		System.out.println("1st WorkSpace name: "+name);
		Assert.assertEquals(name, "Team Workspace");
	}
	
	@Test
	public void validateStatusCode()
	{
		Response resp = rs.get("/workspaces").then().log().all().extract().response();
		assertThat(resp.statusCode(), is(equalTo(200)));
	}
}
