package com.hexaware.apitesting;

import static io.restassured.RestAssured.with;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.filter.log.LogDetail;

public class DownloadFile {
//https://raw.githubusercontent.com/shridharkalagi/AppiumSample/master/ApiDemos-debug.apk

	@BeforeTest
	public void beforeTest()
	{
		RequestSpecBuilder rsb = new RequestSpecBuilder()
				.setBaseUri("https://raw.githubusercontent.com");
		RestAssured.requestSpecification = rsb.build();
		
		ResponseSpecBuilder resb = new ResponseSpecBuilder()
				.expectStatusCode(200)
				.log(LogDetail.ALL);
		RestAssured.responseSpecification = resb.build();
	}
	
	@Test
	public void downloadFile() throws IOException
	{
		InputStream is = with()
		.get("/shridharkalagi/AppiumSample/master/ApiDemos-debug.apk")
		.then().log().all()
		.extract().asInputStream();
		
		OutputStream os = new FileOutputStream(new File("ApiDemos.apk"));
		byte[] bytes = new byte[is.available()];
		is.read(bytes);
		os.write(bytes);
		os.close();
	}
}
