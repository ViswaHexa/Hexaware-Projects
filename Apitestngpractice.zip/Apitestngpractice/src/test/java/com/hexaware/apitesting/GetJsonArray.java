package com.hexaware.apitesting;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.with;
import static org.hamcrest.Matchers.equalTo;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;

public class GetJsonArray {
	
	@BeforeTest
	public void beforeTest()
	{
		RequestSpecBuilder rsb = new RequestSpecBuilder()
				.setBaseUri("https://47f9f570-414c-40e6-a1c9-b553295a82df.mock.pstmn.io")
				.addHeader("Content-Type", "application/json")
				.addHeader("x-mock-match-request-body", "true")
				.log(LogDetail.ALL);
		RestAssured.requestSpecification = rsb.build();
		
		ResponseSpecBuilder resb = new ResponseSpecBuilder()
				.expectStatusCode(200)
				.expectContentType(ContentType.JSON)
				.expectBody("msg", equalTo("Success"))
				.log(LogDetail.ALL);
		RestAssured.responseSpecification = resb.build();
	}
	@Test
	public void getJsonData()
	{
		HashMap<String,String> obj01 = new HashMap<String,String>();
		obj01.put("id", "1");
		obj01.put("type", "None");
		
		HashMap<String,String> obj02 = new HashMap<String,String>();
		obj02.put("id", "2");
		obj02.put("type", "Glazed");
		
		List<Map> listObj = new ArrayList<Map>();
		listObj.add(obj01);
		listObj.add(obj02);
		
		with()
		.body(listObj)
		.post("/post")
		.then().log().all();
	}
}
