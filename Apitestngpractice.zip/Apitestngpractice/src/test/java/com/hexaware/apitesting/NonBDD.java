package com.hexaware.apitesting;

import static io.restassured.RestAssured.get;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.filter.log.LogDetail;
import io.restassured.response.Response;

public class NonBDD {
	
	@BeforeClass
	public void beforeclass()
	{
//		rs = given().baseUri("https://api.postman.com")
//				.header("x-api-key","PMAK-655dc1680358bc23f0d0b314-4210664036d666414aa83a7f04cdae1377")
//				.log().all();
		RequestSpecBuilder rqbuilder = new RequestSpecBuilder();
		rqbuilder.setBaseUri("https://api.postman.com");
		rqbuilder.addHeader("x-api-key","PMAK-655dc1680358bc23f0d0b314-4210664036d666414aa83a7f04cdae1377");
		rqbuilder.log(LogDetail.ALL);
		RestAssured.requestSpecification = rqbuilder.build();
	}
	
	@Test
	public void validateStatusCode()
	{
		Response resp = get("/workspaces").then().extract().response();
		assertThat(resp.statusCode(),is(equalTo(200)));
	}
	
	@Test
	public void validateBody()
	{
		Response resp =get("/workspaces").then().extract().response();
		assertThat(resp.statusCode(),is(equalTo(200)));
		assertThat(resp.path("workspaces[1].name").toString(),equalTo("Team Workspace"));
	}
}
