package com.hexaware.apitesting;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;

public class POSTBDD {
	
	@BeforeClass
	public void requestSpec()
	{
		RequestSpecBuilder rqbuilder = new RequestSpecBuilder()
				.setBaseUri("https://api.postman.com")
				.addHeader("x-api-key","PMAK-655dc1680358bc23f0d0b314-4210664036d666414aa83a7f04cdae1377")
				.setContentType(ContentType.JSON)
				.log(LogDetail.ALL);
		RestAssured.requestSpecification = rqbuilder.build();
		
		ResponseSpecBuilder rsb = new ResponseSpecBuilder()
				.expectStatusCode(200)
				.expectContentType(ContentType.JSON)
				.log(LogDetail.ALL);
		RestAssured.responseSpecification = rsb.build();
	}
	
	@Test
	public void postAutomateWithBDD()
	{
		String payload="{\r\n"
				+ "    \"workspace\":\r\n"
				+ "    {\r\n"
				+ "        \"name\":\"myapiworkspace\",\r\n"
				+ "        \"type\":\"personal\",\r\n"
				+ "        \"description\":\"This workspace is used to API Testing\"\r\n"
				+ "    }\r\n"
				+ "}";
		given()
			.body(payload)
		.when()
				.post("/workspaces")
		.then()
		.log().all()
			.assertThat()
			.body("workspace.name", equalTo("myapiworkspace"),
					"workspace.id", matchesPattern("^[a-z0-9-]{36}$"));
	}
}
