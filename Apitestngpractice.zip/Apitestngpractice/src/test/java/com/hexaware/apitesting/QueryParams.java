package com.hexaware.apitesting;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.filter.log.LogDetail;
import io.restassured.specification.QueryableRequestSpecification;
import io.restassured.specification.SpecificationQuerier;

public class QueryParams {
	
	@BeforeClass
	public void beforeclass()
	{
		RequestSpecBuilder rqbuilder = new RequestSpecBuilder();
		rqbuilder.setBaseUri("https://api.postman.com");
		rqbuilder.addHeader("x-api-key","PMAK-655dc1680358bc23f0d0b314-4210664036d666414aa83a7f04cdae1377");
		rqbuilder.log(LogDetail.ALL);
		RestAssured.requestSpecification = rqbuilder.build();
	}
	
	@Test
	public void queryTest()
	{
		QueryableRequestSpecification qrs = SpecificationQuerier.query(RestAssured.requestSpecification);
		System.out.println(qrs.getBaseUri());
		System.out.println(qrs.getHeaders());
	}
}
