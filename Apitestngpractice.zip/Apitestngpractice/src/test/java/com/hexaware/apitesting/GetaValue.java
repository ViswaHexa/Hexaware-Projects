package com.hexaware.apitesting;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.annotations.Test;

public class GetaValue {

	@Test
	public void getaValue()
	{
		String name = given()
				.baseUri("https://api.postman.com")
				.header("x-api-key","PMAK-655dc1680358bc23f0d0b314-4210664036d666414aa83a7f04cdae1377")
			.when()
				.get("/workspaces")
			.then().log().ifError()
				.assertThat().statusCode(200).extract().response().path("workspaces[1].name");
		
		System.out.println("1st WorkSpace name: "+name);
		
		Assert.assertEquals(name, "Team Workspace");
				
	}
}
