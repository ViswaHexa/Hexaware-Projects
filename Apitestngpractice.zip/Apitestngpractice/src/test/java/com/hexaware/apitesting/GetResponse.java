package com.hexaware.apitesting;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

public class GetResponse {
	
	@Test
	public void getResponse()
	{
		String res = given()
		.baseUri("https://api.postman.com")
		.header("x-api-key","PMAK-655dc1680358bc23f0d0b314-4210664036d666414aa83a7f04cdae1377")
	.when()
		.get("/workspaces")
	.then()
		// 1//.assertThat().statusCode(200).extract().response().asString();
		.assertThat().statusCode(200).extract().response().asString();
		
		
		//4
		System.out.println("WorkSpace Name: "+res);
		
		
		//1
//		System.out.println("WorkSpace Name: "+JsonPath.from(res).getString("workspaces[1].name"));
		
		//2
//		JsonPath js = new JsonPath(res.asString());
//		System.out.println("WorkSpace Name: "+js.getString("workspaces[1].name"));
		
		//3
//		System.out.println("Response"+res.asString());
//		System.out.println("WorkSpace Name: "+ res.path("workspaces[1].name"));
	}
}
