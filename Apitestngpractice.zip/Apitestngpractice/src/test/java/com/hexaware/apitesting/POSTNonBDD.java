package com.hexaware.apitesting;

import static io.restassured.RestAssured.with;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.matchesPattern;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class POSTNonBDD {
	
	@BeforeClass
	public void requestSpec()
	{
		RequestSpecBuilder rqbuilder = new RequestSpecBuilder()
				.setBaseUri("https://api.postman.com")
				.addHeader("x-api-key","PMAK-655dc1680358bc23f0d0b314-4210664036d666414aa83a7f04cdae1377")
				.setContentType(ContentType.JSON)
				.log(LogDetail.ALL);
		RestAssured.requestSpecification = rqbuilder.build();
		
		ResponseSpecBuilder rsb = new ResponseSpecBuilder()
				.expectStatusCode(200)
				.expectContentType(ContentType.JSON)
				.log(LogDetail.ALL);
		RestAssured.responseSpecification = rsb.build();
	}
	
	@Test
	public void postAutomateWithBDD()
	{
		String payload="{\r\n"
				+ "    \"workspace\":\r\n"
				+ "    {\r\n"
				+ "        \"name\":\"MyAPITestingWorkspace\",\r\n"
				+ "        \"type\":\"personal\",\r\n"
				+ "        \"description\":\"This workspace is used to API Testing\"\r\n"
				+ "    }\r\n"
				+ "}";
		
		Response res = with()
			.body(payload)
			.post("/workspaces");
		assertThat(res.<String>path("workspace.name"),equalTo("MyAPITestingWorkspace"));
		assertThat(res.<String>path("workspace.id"), matchesPattern("^[a-z0-9-]{36}$"));
		
	}
}
