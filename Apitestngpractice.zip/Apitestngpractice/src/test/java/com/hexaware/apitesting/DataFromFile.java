package com.hexaware.apitesting;

import static io.restassured.RestAssured.with;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

import java.io.File;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class DataFromFile {
	
	@BeforeClass
	public void requestSpec()
	{
		RequestSpecBuilder rqbuilder = new RequestSpecBuilder()
				.setBaseUri("https://api.postman.com")
				.addHeader("x-api-key","PMAK-655dc1680358bc23f0d0b314-4210664036d666414aa83a7f04cdae1377")
				.setContentType(ContentType.JSON)
				.log(LogDetail.ALL);
		RestAssured.requestSpecification = rqbuilder.build();
		
		ResponseSpecBuilder rsb = new ResponseSpecBuilder()
				.expectStatusCode(200)
				.expectContentType(ContentType.JSON)
				.log(LogDetail.ALL);
		RestAssured.responseSpecification = rsb.build();
	}
	
	@Test
	public void getDataFromFile()
	{
		//File file = new File("src/test/java/com/hexaware/DataFiles/payload.json");
		Response res= with()
			.body(new File("src/test/java/com/hexaware/DataFiles/payload.json"))
			.post("/workspaces");
		assertThat(res.<String>path("workspace.name"), equalTo("My WorkSpace44"));
			
	}
}
