package com.hexaware.apitesting;

import static io.restassured.RestAssured.with;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;

import java.util.HashMap;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class GetDataFromMap {
	
	@BeforeClass
	public void requestSpec()
	{
		RequestSpecBuilder rqbuilder = new RequestSpecBuilder()
				.setBaseUri("https://api.postman.com")
				.addHeader("x-api-key","PMAK-655dc1680358bc23f0d0b314-4210664036d666414aa83a7f04cdae1377")
				.setContentType(ContentType.JSON)
				.log(LogDetail.ALL);
		RestAssured.requestSpecification = rqbuilder.build();
		
		ResponseSpecBuilder rsb = new ResponseSpecBuilder()
				.expectStatusCode(200)
				.expectContentType(ContentType.JSON)
				.log(LogDetail.ALL);
		RestAssured.responseSpecification = rsb.build();
	}
	
	@Test
	public void getDataFromMap()
	{
		HashMap<String,String> nestedData = new HashMap<String,String>();
		nestedData.put("name", "MyWorkSpace1");
		nestedData.put("type", "personal");
		nestedData.put("description", "To add new workspace");
		
		HashMap<String,Object> mainObject = new HashMap<String,Object>();
		mainObject.put("workspace", nestedData);
		Response res = with()
			.body(mainObject)
			.post("/workspaces");
		assertThat(res.<String>path("workspace.name"),equalTo("MyWorkSpace1"));
	}
}
