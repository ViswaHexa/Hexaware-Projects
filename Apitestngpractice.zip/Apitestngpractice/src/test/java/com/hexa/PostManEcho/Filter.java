package com.hexa.PostManEcho;

import static io.restassured.RestAssured.with;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.filter.log.LogDetail;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;

public class Filter {

	@BeforeClass
	public void beforeClass()
	{
		RequestSpecBuilder rsb = new RequestSpecBuilder()
				.setBaseUri("https://postman-echo.com")
				.addFilter(new RequestLoggingFilter(LogDetail.BODY))
				.addFilter(new ResponseLoggingFilter(LogDetail.STATUS));
		RestAssured.requestSpecification = rsb.build();
		
		ResponseSpecBuilder resb = new ResponseSpecBuilder()
				.expectStatusCode(200);
		RestAssured.responseSpecification = resb.build();
	}
	
	@Test
	public void multipleValueQueryParams()
	{
		with()
			.get("/get");
	}
}
