package com.hexa.PostManEcho;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.with;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;

public class JsonSchema {
	
	@Test
	public void validateJsonSchema()
	{
		with()
		.baseUri("https://postman-echo.com")
		.get("/get")
		.then()
			.log().all()
			.assertThat().statusCode(200)
			.body(matchesJsonSchemaInClasspath("EchoJson.json"));
	}
}
