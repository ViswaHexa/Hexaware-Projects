package com.hexa.PostManEcho;

import static io.restassured.RestAssured.with;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.filter.log.LogDetail;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;

public class LogFile {
	
	@BeforeClass
	public void beforeClass() throws FileNotFoundException
	{
		
		
		RequestSpecBuilder rsb = new RequestSpecBuilder()
				.setBaseUri("https://postman-echo.com");
		RestAssured.requestSpecification = rsb.build();
		
		ResponseSpecBuilder resb = new ResponseSpecBuilder()
				.expectStatusCode(200);
		RestAssured.responseSpecification = resb.build();
	}
	
	@Test
	public void addResponseToLogFile() throws FileNotFoundException
	{
		PrintStream fileoutput = new PrintStream(new File("restAssured.log"));
		
		with()
//			.filter(new RequestLoggingFilter(fileoutput))
			.filter(new ResponseLoggingFilter(fileoutput))
			.filter(new RequestLoggingFilter(LogDetail.BODY,fileoutput))
//			.filter(new ResponseLoggingFilter(LogDetail.STATUS,fileoutput))
			.get("/get").then().log().all();
	}
}
