package com.hexa.PostManEcho;

import static io.restassured.RestAssured.with;

import java.util.HashMap;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.filter.log.LogDetail;

public class GetEcho {

	@BeforeClass
	public void beforeClass()
	{
		RequestSpecBuilder rsb = new RequestSpecBuilder()
				.setBaseUri("https://postman-echo.com")
//				.addQueryParam("foo1", "bar1")
//				.addQueryParam("foo2", "bar2")
				.log(LogDetail.ALL);
		RestAssured.requestSpecification = rsb.build();
		
		ResponseSpecBuilder resb = new ResponseSpecBuilder()
				.expectStatusCode(200);
		RestAssured.responseSpecification = resb.build();
	}
	
//	@Test
//	public void getMultipleParams()
//	{
//		HashMap<String,String> paramObj = new HashMap<String,String>();
//		paramObj.put("foo1", "bar1");
//		paramObj.put("foo2", "bar2");
//		with()
//			.params(paramObj)
//			.get("/get")
//			.then().log().all();
//		
//	}
	@Test
	public void multipleValueQueryParams()
	{
		with()
//		.param("foo1", "bar1","bar2","bar3")
//		.param("foo1","bar1;bar2;bar3")
		.get("/get")
		.then().log().all();
	}
}
